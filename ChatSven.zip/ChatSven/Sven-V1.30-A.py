import json
import time
import wikipedia
import os
from colorama import init, Fore

# Inicializar colorama
init(autoreset=True)

# Archivos de configuración y memoria
CONFIG_FILE = "config.json"
MEMORIA_FILE = "memoria.json"

# 1. Crear archivo de configuración si no existe
def crear_config_si_no_existe():
    if not os.path.exists(CONFIG_FILE):
        config_default = {
            "velocidad_escritura": 0.03,
            "color_usuario": "YELLOW",
            "color_sven": "GREEN",
            "color_nombre_usuario": "YELLOW",
            "mostrar_nombre_sven": True,
            "nombre_sven": "Sven",
            "mostrar_nombre_usuario": True,
            "nombre_usuario": "Jugador",
            "mensaje_inicio": "¡Samuel {nombre_usuario}, bienvenido a Sven!",
            "direccion_texto_sven": "izquierda",
            "direccion_texto_usuario": "derecha",
            "color_fondo_cmd": "BLACK",
            "sonido_notificacion": True,
            "formato_hora": "24H",
            "tema_visual": "oscuro",
            "animaciones_texto": True
        }
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config_default, f, indent=4)

# 2. Cargar configuración
def cargar_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error al cargar config.json: {e}")
        return {}

# 3. Cargar memoria o crear nueva
def cargar_memoria():
    if not os.path.exists(MEMORIA_FILE):
        return {"respuestas": {}}
    try:
        with open(MEMORIA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"respuestas": {}}

# 4. Guardar memoria
def guardar_memoria(memoria):
    with open(MEMORIA_FILE, "w", encoding="utf-8") as f:
        json.dump(memoria, f, indent=4, ensure_ascii=False)

# 5. Agregar respuesta a la memoria
def agregar_respuesta(pregunta, respuesta):
    memoria = cargar_memoria()
    memoria["respuestas"][pregunta] = respuesta
    guardar_memoria(memoria)

# 6. Obtener respuesta de la memoria
def obtener_respuesta(pregunta):
    return cargar_memoria()["respuestas"].get(pregunta, "No sé la respuesta.")

# 7. Escribir con efecto de letra por letra
def escribir_sven(texto, config):
    print()
    color = getattr(Fore, config.get("color_sven", "GREEN"))
    nombre = f"{config['nombre_sven']}: " if config["mostrar_nombre_sven"] else ""
    texto_completo = nombre + texto
    for letra in texto_completo:
        print(color + letra, end="", flush=True)
        time.sleep(config.get("velocidad_escritura", 0.03))
    print("\n")

# 8. Formato de entrada del usuario
def escribir_usuario(config):
    color_nombre = getattr(Fore, config.get("color_nombre_usuario", "YELLOW"))
    color_texto = getattr(Fore, config.get("color_usuario", "YELLOW"))
    nombre = f"{color_nombre}{config['nombre_usuario']}: " if config["mostrar_nombre_usuario"] else ""
    return f"\n{nombre}{color_texto}:>> "

# 9. Buscar en Wikipedia
def buscar_wikipedia(consulta):
    try:
        wikipedia.set_lang("es")
        return wikipedia.summary(consulta, sentences=2)
    except:
        return None

# 10. Iniciar Sven
def iniciar_sven():
    crear_config_si_no_existe()
    config = cargar_config()
    memoria = cargar_memoria()
    escribir_sven(config["mensaje_inicio"].format(nombre_usuario=config["nombre_usuario"]), config)
    
    while True:
        entrada = input(escribir_usuario(config)).strip().lower()

        if entrada == "/memoria":
            escribir_sven(json.dumps(memoria, indent=4, ensure_ascii=False), config)
            continue

        if entrada.startswith("/piensa:"):
            consulta = entrada.replace("/piensa:", "").strip()
            escribir_sven("Hmm... Déjame pensar en eso...", config)
            time.sleep(2)
            respuesta = buscar_wikipedia(consulta)
            if respuesta:
                agregar_respuesta(consulta, respuesta)
            escribir_sven(respuesta if respuesta else "No encontré información. ☻ ", config)
            continue

        if entrada in ["salir", "adios", "exit"]:
            escribir_sven("¡Hasta luego! Guardando memoria...", config)
            guardar_memoria(memoria)
            break

        respuesta = obtener_respuesta(entrada)
        if respuesta != "No sé la respuesta.":
            escribir_sven(respuesta, config)
        else:
            escribir_sven("No sé la respuesta... ¿Quieres que la busque en Wikipedia? (/Si o /No) ☻ ", config)
            decision = input(escribir_usuario(config)).strip().lower()

            if decision == "/si":
                respuesta = buscar_wikipedia(entrada)
                if respuesta:
                    agregar_respuesta(entrada, respuesta)
                    escribir_sven(respuesta, config)
                else:
                    escribir_sven("No encontré información.", config)

            elif decision == "/no":
                escribir_sven("¿Cuál es la respuesta correcta? (Presiona ENTER sin escribir para no guardar ☻ )", config)
                nueva_respuesta = input(escribir_usuario(config)).strip()
                if nueva_respuesta:
                    agregar_respuesta(entrada, nueva_respuesta)
                    escribir_sven("¡Gracias! He guardado la respuesta en mi memoria. ☻ ", config)
                else:
                    escribir_sven("No se guardó ninguna respuesta. ☻ ", config)

if __name__ == "__main__":
    iniciar_sven()